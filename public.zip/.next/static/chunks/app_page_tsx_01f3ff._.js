(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_01f3ff._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_01f3ff._.js",
  "chunks": [
    "static/chunks/node_modules_axios_lib_c4c49c._.js",
    "static/chunks/node_modules_react-icons_io5_index_mjs_39106f._.js",
    "static/chunks/node_modules_8fb10e._.js",
    "static/chunks/_97eb3d._.js"
  ],
  "source": "dynamic"
});
