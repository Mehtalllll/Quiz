(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_tsx_202b73._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_tsx_202b73._.js",
  "chunks": [
    "static/chunks/node_modules_react-icons_ri_index_mjs_0e2ec0._.js",
    "static/chunks/node_modules_react-icons_lu_index_mjs_26d8a9._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_d35cf4._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_8d32d4._.js",
    "static/chunks/_ee5bb0._.js",
    "static/chunks/app_globals_73c377.css"
  ],
  "source": "dynamic"
});
