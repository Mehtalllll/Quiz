(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_effddb._.js", {

"[project]/app/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "Products": (()=>Products)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$Hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/Redux/Hook.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$Listapi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/api/Listapi.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$features$2f$productsSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/Redux/features/productsSlice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Components$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/src/Components/card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/useQuery.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
'use client';
;
;
;
;
;
;
const Products = ()=>{
    _s();
    const [categoryFilter, setCategoryFilter] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState('all');
    const [priceRange, setPriceRange] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState([
        0,
        1000
    ]);
    const dispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$Hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"])();
    const productsList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            'initialproduts'
        ],
        queryFn: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$api$2f$Listapi$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FetchProducts"]
    });
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useEffect(()=>{
        if (productsList.isSuccess && productsList.data) {
            dispatch(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$features$2f$productsSlice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["productsSliceactions"].addtoListItem(productsList.data.products));
        }
    }, [
        productsList.isSuccess,
        productsList.data,
        dispatch
    ]);
    const Products = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$Hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppSelector"])((state)=>state.products.products[0]);
    console.log(Products);
    const productList = Array.isArray(Products) ? Products : [];
    const filteredProducts = productList.filter((product)=>{
        const isCategoryMatch = categoryFilter === 'all' || product.category === categoryFilter;
        const isPriceMatch = product.price >= priceRange[0] && product.price <= priceRange[1];
        return isCategoryMatch && isPriceMatch;
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "inline-flex w-full mt-20",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full max-w-[325px] bg-slate-700 h-screen hidden md:block",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full max-w-[325px] bg-slate-700 h-screen p-4 hidden md:block",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-white",
                            children: "Filter by Category:"
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                            className: "w-full p-2 mb-4",
                            value: categoryFilter,
                            onChange: (e)=>setCategoryFilter(e.target.value),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                value: "all",
                                children: "All Categories"
                            }, void 0, false, {
                                fileName: "[project]/app/page.tsx",
                                lineNumber: 52,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 47,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                            className: "text-white",
                            children: "Price Range:"
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 55,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    value: priceRange[0],
                                    onChange: (e)=>setPriceRange([
                                            Number(e.target.value),
                                            priceRange[1]
                                        ]),
                                    className: "w-1/2 p-2 mb-4",
                                    min: "0",
                                    max: "1000"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 57,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                    type: "number",
                                    value: priceRange[1],
                                    onChange: (e)=>setPriceRange([
                                            priceRange[0],
                                            Number(e.target.value)
                                        ]),
                                    className: "w-1/2 p-2 mb-4",
                                    min: "0",
                                    max: "1000"
                                }, void 0, false, {
                                    fileName: "[project]/app/page.tsx",
                                    lineNumber: 67,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 56,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 45,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-slate-300 w-full grid gap-y-3 grid-cols-1 h-screen overflow-y-scroll lg:grid-cols-2 xl:grid-cols-3 p-4 no-scrollbar",
                children: productsList.isLoading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-5xl text-center",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/app/page.tsx",
                    lineNumber: 82,
                    columnNumber: 11
                }, this) : filteredProducts?.map((el)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mx-auto",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Components$2f$card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Carditem"], {
                            AddorRemove: true,
                            item: el
                        }, void 0, false, {
                            fileName: "[project]/app/page.tsx",
                            lineNumber: 86,
                            columnNumber: 15
                        }, this)
                    }, `${el.id}-${Math.random()}`, false, {
                        fileName: "[project]/app/page.tsx",
                        lineNumber: 85,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 80,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
};
_s(Products, "1RRUcdIXoMXZwkVnMRw+Zw6jrNY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$Hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppDispatch"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$Redux$2f$Hook$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAppSelector"]
    ];
});
_c = Products;
var _c;
__turbopack_refresh__.register(_c, "Products");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/app/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: require } = __turbopack_context__;
{
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/isRestoring.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "IsRestoringProvider": (()=>IsRestoringProvider),
    "useIsRestoring": (()=>useIsRestoring)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
const IsRestoringContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.createContext(false);
const useIsRestoring = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useContext(IsRestoringContext);
const IsRestoringProvider = IsRestoringContext.Provider;
;
 //# sourceMappingURL=isRestoring.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/QueryErrorResetBoundary.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "QueryErrorResetBoundary": (()=>QueryErrorResetBoundary),
    "useQueryErrorResetBoundary": (()=>useQueryErrorResetBoundary)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
'use client';
;
function createValue() {
    let isReset = false;
    return {
        clearReset: ()=>{
            isReset = false;
        },
        reset: ()=>{
            isReset = true;
        },
        isReset: ()=>{
            return isReset;
        }
    };
}
const QueryErrorResetBoundaryContext = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.createContext(createValue()); // HOOK
const useQueryErrorResetBoundary = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useContext(QueryErrorResetBoundaryContext); // COMPONENT
const QueryErrorResetBoundary = ({ children })=>{
    const [value] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useState(()=>createValue());
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.createElement(QueryErrorResetBoundaryContext.Provider, {
        value: value
    }, typeof children === 'function' ? children(value) : children);
};
;
 //# sourceMappingURL=QueryErrorResetBoundary.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/suspense.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ensureStaleTime": (()=>ensureStaleTime),
    "fetchOptimistic": (()=>fetchOptimistic),
    "shouldSuspend": (()=>shouldSuspend),
    "willFetch": (()=>willFetch)
});
const ensureStaleTime = (defaultedOptions)=>{
    if (defaultedOptions.suspense) {
        // Always set stale time when using suspense to prevent
        // fetching again when directly mounting after suspending
        if (typeof defaultedOptions.staleTime !== 'number') {
            defaultedOptions.staleTime = 1000;
        }
    }
};
const willFetch = (result, isRestoring)=>result.isLoading && result.isFetching && !isRestoring;
const shouldSuspend = (defaultedOptions, result, isRestoring)=>(defaultedOptions == null ? void 0 : defaultedOptions.suspense) && willFetch(result, isRestoring);
const fetchOptimistic = (defaultedOptions, observer, errorResetBoundary)=>observer.fetchOptimistic(defaultedOptions).then(({ data })=>{
        defaultedOptions.onSuccess == null ? void 0 : defaultedOptions.onSuccess(data);
        defaultedOptions.onSettled == null ? void 0 : defaultedOptions.onSettled(data, null);
    }).catch((error)=>{
        errorResetBoundary.clearReset();
        defaultedOptions.onError == null ? void 0 : defaultedOptions.onError(error);
        defaultedOptions.onSettled == null ? void 0 : defaultedOptions.onSettled(undefined, error);
    });
;
 //# sourceMappingURL=suspense.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/utils.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "shouldThrowError": (()=>shouldThrowError)
});
function shouldThrowError(_useErrorBoundary, params) {
    // Allow useErrorBoundary function to override throwing behavior on a per-error basis
    if (typeof _useErrorBoundary === 'function') {
        return _useErrorBoundary(...params);
    }
    return !!_useErrorBoundary;
}
;
 //# sourceMappingURL=utils.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/errorBoundaryUtils.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "ensurePreventErrorBoundaryRetry": (()=>ensurePreventErrorBoundaryRetry),
    "getHasError": (()=>getHasError),
    "useClearResetErrorBoundary": (()=>useClearResetErrorBoundary)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/utils.mjs [app-client] (ecmascript)");
'use client';
;
;
const ensurePreventErrorBoundaryRetry = (options, errorResetBoundary)=>{
    if (options.suspense || options.useErrorBoundary) {
        // Prevent retrying failed query if the error boundary has not been reset yet
        if (!errorResetBoundary.isReset()) {
            options.retryOnMount = false;
        }
    }
};
const useClearResetErrorBoundary = (errorResetBoundary)=>{
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useEffect(()=>{
        errorResetBoundary.clearReset();
    }, [
        errorResetBoundary
    ]);
};
const getHasError = ({ result, errorResetBoundary, useErrorBoundary, query })=>{
    return result.isError && !errorResetBoundary.isReset() && !result.isFetching && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldThrowError"])(useErrorBoundary, [
        result.error,
        query
    ]);
};
;
 //# sourceMappingURL=errorBoundaryUtils.mjs.map
}}),
"[project]/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: require } = __turbopack_context__;
{
/**
 * @license React
 * use-sync-external-store-shim.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time truthy", 1) {
    (function() {
        'use strict';
        /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */ if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart === 'function') {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(new Error());
        }
        var React = __turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
        var ReactSharedInternals = React.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED;
        function error(format) {
            {
                {
                    for(var _len2 = arguments.length, args = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++){
                        args[_key2 - 1] = arguments[_key2];
                    }
                    printWarning('error', format, args);
                }
            }
        }
        function printWarning(level, format, args) {
            // When changing this logic, you might want to also
            // update consoleWithStackDev.www.js as well.
            {
                var ReactDebugCurrentFrame = ReactSharedInternals.ReactDebugCurrentFrame;
                var stack = ReactDebugCurrentFrame.getStackAddendum();
                if (stack !== '') {
                    format += '%s';
                    args = args.concat([
                        stack
                    ]);
                } // eslint-disable-next-line react-internal/safe-string-coercion
                var argsWithFormat = args.map(function(item) {
                    return String(item);
                }); // Careful: RN currently depends on this prefix
                argsWithFormat.unshift('Warning: ' + format); // We intentionally don't use spread (or .apply) directly because it
                // breaks IE9: https://github.com/facebook/react/issues/13610
                // eslint-disable-next-line react-internal/no-production-logging
                Function.prototype.apply.call(console[level], console, argsWithFormat);
            }
        }
        /**
 * inlined Object.is polyfill to avoid requiring consumers ship their own
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/is
 */ function is(x, y) {
            return x === y && (x !== 0 || 1 / x === 1 / y) || x !== x && y !== y // eslint-disable-line no-self-compare
            ;
        }
        var objectIs = typeof Object.is === 'function' ? Object.is : is;
        // dispatch for CommonJS interop named imports.
        var useState = React.useState, useEffect = React.useEffect, useLayoutEffect = React.useLayoutEffect, useDebugValue = React.useDebugValue;
        var didWarnOld18Alpha = false;
        var didWarnUncachedGetSnapshot = false; // Disclaimer: This shim breaks many of the rules of React, and only works
        // because of a very particular set of implementation details and assumptions
        // -- change any one of them and it will break. The most important assumption
        // is that updates are always synchronous, because concurrent rendering is
        // only available in versions of React that also have a built-in
        // useSyncExternalStore API. And we only use this shim when the built-in API
        // does not exist.
        //
        // Do not assume that the clever hacks used by this hook also work in general.
        // The point of this shim is to replace the need for hacks by other libraries.
        function useSyncExternalStore(subscribe, getSnapshot, // React do not expose a way to check if we're hydrating. So users of the shim
        // will need to track that themselves and return the correct value
        // from `getSnapshot`.
        getServerSnapshot) {
            {
                if (!didWarnOld18Alpha) {
                    if (React.startTransition !== undefined) {
                        didWarnOld18Alpha = true;
                        error('You are using an outdated, pre-release alpha of React 18 that ' + 'does not support useSyncExternalStore. The ' + 'use-sync-external-store shim will not work correctly. Upgrade ' + 'to a newer pre-release.');
                    }
                }
            }
            // breaks the rules of React, and only works here because of specific
            // implementation details, most importantly that updates are
            // always synchronous.
            var value = getSnapshot();
            {
                if (!didWarnUncachedGetSnapshot) {
                    var cachedValue = getSnapshot();
                    if (!objectIs(value, cachedValue)) {
                        error('The result of getSnapshot should be cached to avoid an infinite loop');
                        didWarnUncachedGetSnapshot = true;
                    }
                }
            }
            // re-render whenever the subscribed state changes by updating an some
            // arbitrary useState hook. Then, during render, we call getSnapshot to read
            // the current value.
            //
            // Because we don't actually use the state returned by the useState hook, we
            // can save a bit of memory by storing other stuff in that slot.
            //
            // To implement the early bailout, we need to track some things on a mutable
            // object. Usually, we would put that in a useRef hook, but we can stash it in
            // our useState hook instead.
            //
            // To force a re-render, we call forceUpdate({inst}). That works because the
            // new object always fails an equality check.
            var _useState = useState({
                inst: {
                    value: value,
                    getSnapshot: getSnapshot
                }
            }), inst = _useState[0].inst, forceUpdate = _useState[1]; // Track the latest getSnapshot function with a ref. This needs to be updated
            // in the layout phase so we can access it during the tearing check that
            // happens on subscribe.
            useLayoutEffect(function() {
                inst.value = value;
                inst.getSnapshot = getSnapshot; // Whenever getSnapshot or subscribe changes, we need to check in the
                // commit phase if there was an interleaved mutation. In concurrent mode
                // this can happen all the time, but even in synchronous mode, an earlier
                // effect may have mutated the store.
                if (checkIfSnapshotChanged(inst)) {
                    // Force a re-render.
                    forceUpdate({
                        inst: inst
                    });
                }
            }, [
                subscribe,
                value,
                getSnapshot
            ]);
            useEffect(function() {
                // Check for changes right before subscribing. Subsequent changes will be
                // detected in the subscription handler.
                if (checkIfSnapshotChanged(inst)) {
                    // Force a re-render.
                    forceUpdate({
                        inst: inst
                    });
                }
                var handleStoreChange = function() {
                    // TODO: Because there is no cross-renderer API for batching updates, it's
                    // up to the consumer of this library to wrap their subscription event
                    // with unstable_batchedUpdates. Should we try to detect when this isn't
                    // the case and print a warning in development?
                    // The store changed. Check if the snapshot changed since the last time we
                    // read from the store.
                    if (checkIfSnapshotChanged(inst)) {
                        // Force a re-render.
                        forceUpdate({
                            inst: inst
                        });
                    }
                }; // Subscribe to the store and return a clean-up function.
                return subscribe(handleStoreChange);
            }, [
                subscribe
            ]);
            useDebugValue(value);
            return value;
        }
        function checkIfSnapshotChanged(inst) {
            var latestGetSnapshot = inst.getSnapshot;
            var prevValue = inst.value;
            try {
                var nextValue = latestGetSnapshot();
                return !objectIs(prevValue, nextValue);
            } catch (error) {
                return true;
            }
        }
        function useSyncExternalStore$1(subscribe, getSnapshot, getServerSnapshot) {
            // Note: The shim does not use getServerSnapshot, because pre-18 versions of
            // React do not expose a way to check if we're hydrating. So users of the shim
            // will need to track that themselves and return the correct value
            // from `getSnapshot`.
            return getSnapshot();
        }
        var canUseDOM = !!(typeof window !== 'undefined' && typeof window.document !== 'undefined' && typeof window.document.createElement !== 'undefined');
        var isServerEnvironment = !canUseDOM;
        var shim = isServerEnvironment ? useSyncExternalStore$1 : useSyncExternalStore;
        var useSyncExternalStore$2 = React.useSyncExternalStore !== undefined ? React.useSyncExternalStore : shim;
        exports.useSyncExternalStore = useSyncExternalStore$2;
        /* global __REACT_DEVTOOLS_GLOBAL_HOOK__ */ if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ !== 'undefined' && typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop === 'function') {
            __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(new Error());
        }
    })();
}
}}),
"[project]/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: require } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    module.exports = __turbopack_require__("[project]/node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js [app-client] (ecmascript)");
}
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/useSyncExternalStore.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useSyncExternalStore": (()=>useSyncExternalStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/use-sync-external-store/shim/index.js [app-client] (ecmascript)");
'use client';
;
const useSyncExternalStore = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$sync$2d$external$2d$store$2f$shim$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"];
;
 //# sourceMappingURL=useSyncExternalStore.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/useBaseQuery.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useBaseQuery": (()=>useBaseQuery)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$QueryClientProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/QueryClientProvider.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$isRestoring$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/isRestoring.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$QueryErrorResetBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/QueryErrorResetBoundary.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/notifyManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$suspense$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/suspense.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$errorBoundaryUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/errorBoundaryUtils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useSyncExternalStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/useSyncExternalStore.mjs [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
;
function useBaseQuery(options, Observer) {
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$QueryClientProvider$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])({
        context: options.context
    });
    const isRestoring = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$isRestoring$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useIsRestoring"])();
    const errorResetBoundary = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$QueryErrorResetBoundary$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryErrorResetBoundary"])();
    const defaultedOptions = queryClient.defaultQueryOptions(options); // Make sure results are optimistically set in fetching state before subscribing or updating options
    defaultedOptions._optimisticResults = isRestoring ? 'isRestoring' : 'optimistic'; // Include callbacks in batch renders
    if (defaultedOptions.onError) {
        defaultedOptions.onError = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batchCalls(defaultedOptions.onError);
    }
    if (defaultedOptions.onSuccess) {
        defaultedOptions.onSuccess = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batchCalls(defaultedOptions.onSuccess);
    }
    if (defaultedOptions.onSettled) {
        defaultedOptions.onSettled = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batchCalls(defaultedOptions.onSettled);
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$suspense$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureStaleTime"])(defaultedOptions);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$errorBoundaryUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensurePreventErrorBoundaryRetry"])(defaultedOptions, errorResetBoundary);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$errorBoundaryUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useClearResetErrorBoundary"])(errorResetBoundary);
    const [observer] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useState(()=>new Observer(queryClient, defaultedOptions));
    const result = observer.getOptimisticResult(defaultedOptions);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useSyncExternalStore$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useCallback((onStoreChange)=>{
        const unsubscribe = isRestoring ? ()=>undefined : observer.subscribe(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batchCalls(onStoreChange)); // Update result to make sure we did not miss any query updates
        // between creating the observer and subscribing to it.
        observer.updateResult();
        return unsubscribe;
    }, [
        observer,
        isRestoring
    ]), ()=>observer.getCurrentResult(), ()=>observer.getCurrentResult());
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__.useEffect(()=>{
        // Do not notify on updates because of changes in the options because
        // these changes should already be reflected in the optimistic result.
        observer.setOptions(defaultedOptions, {
            listeners: false
        });
    }, [
        defaultedOptions,
        observer
    ]); // Handle suspense
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$suspense$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shouldSuspend"])(defaultedOptions, result, isRestoring)) {
        throw (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$suspense$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchOptimistic"])(defaultedOptions, observer, errorResetBoundary);
    } // Handle error boundary
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$errorBoundaryUtils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getHasError"])({
        result,
        errorResetBoundary,
        useErrorBoundary: defaultedOptions.useErrorBoundary,
        query: observer.getCurrentQuery()
    })) {
        throw result.error;
    } // Handle result property usage tracking
    return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
;
 //# sourceMappingURL=useBaseQuery.mjs.map
}}),
"[project]/node_modules/@tanstack/query-core/build/lib/queryObserver.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "QueryObserver": (()=>QueryObserver)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$focusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/focusManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$retryer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/retryer.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/notifyManager.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$subscribable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/subscribable.mjs [app-client] (ecmascript)");
;
;
;
;
;
class QueryObserver extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$subscribable$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Subscribable"] {
    constructor(client, options){
        super();
        this.client = client;
        this.options = options;
        this.trackedProps = new Set();
        this.selectError = null;
        this.bindMethods();
        this.setOptions(options);
    }
    bindMethods() {
        this.remove = this.remove.bind(this);
        this.refetch = this.refetch.bind(this);
    }
    onSubscribe() {
        if (this.listeners.size === 1) {
            this.currentQuery.addObserver(this);
            if (shouldFetchOnMount(this.currentQuery, this.options)) {
                this.executeFetch();
            }
            this.updateTimers();
        }
    }
    onUnsubscribe() {
        if (!this.hasListeners()) {
            this.destroy();
        }
    }
    shouldFetchOnReconnect() {
        return shouldFetchOn(this.currentQuery, this.options, this.options.refetchOnReconnect);
    }
    shouldFetchOnWindowFocus() {
        return shouldFetchOn(this.currentQuery, this.options, this.options.refetchOnWindowFocus);
    }
    destroy() {
        this.listeners = new Set();
        this.clearStaleTimeout();
        this.clearRefetchInterval();
        this.currentQuery.removeObserver(this);
    }
    setOptions(options, notifyOptions) {
        const prevOptions = this.options;
        const prevQuery = this.currentQuery;
        this.options = this.client.defaultQueryOptions(options);
        if (("TURBOPACK compile-time value", "development") !== 'production' && typeof (options == null ? void 0 : options.isDataEqual) !== 'undefined') {
            this.client.getLogger().error("The isDataEqual option has been deprecated and will be removed in the next major version. You can achieve the same functionality by passing a function as the structuralSharing option");
        }
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqualObjects"])(prevOptions, this.options)) {
            this.client.getQueryCache().notify({
                type: 'observerOptionsUpdated',
                query: this.currentQuery,
                observer: this
            });
        }
        if (typeof this.options.enabled !== 'undefined' && typeof this.options.enabled !== 'boolean') {
            throw new Error('Expected enabled to be a boolean');
        } // Keep previous query key if the user does not supply one
        if (!this.options.queryKey) {
            this.options.queryKey = prevOptions.queryKey;
        }
        this.updateQuery();
        const mounted = this.hasListeners(); // Fetch if there are subscribers
        if (mounted && shouldFetchOptionally(this.currentQuery, prevQuery, this.options, prevOptions)) {
            this.executeFetch();
        } // Update result
        this.updateResult(notifyOptions); // Update stale interval if needed
        if (mounted && (this.currentQuery !== prevQuery || this.options.enabled !== prevOptions.enabled || this.options.staleTime !== prevOptions.staleTime)) {
            this.updateStaleTimeout();
        }
        const nextRefetchInterval = this.computeRefetchInterval(); // Update refetch interval if needed
        if (mounted && (this.currentQuery !== prevQuery || this.options.enabled !== prevOptions.enabled || nextRefetchInterval !== this.currentRefetchInterval)) {
            this.updateRefetchInterval(nextRefetchInterval);
        }
    }
    getOptimisticResult(options) {
        const query = this.client.getQueryCache().build(this.client, options);
        const result = this.createResult(query, options);
        if (shouldAssignObserverCurrentProperties(this, result, options)) {
            // this assigns the optimistic result to the current Observer
            // because if the query function changes, useQuery will be performing
            // an effect where it would fetch again.
            // When the fetch finishes, we perform a deep data cloning in order
            // to reuse objects references. This deep data clone is performed against
            // the `observer.currentResult.data` property
            // When QueryKey changes, we refresh the query and get new `optimistic`
            // result, while we leave the `observer.currentResult`, so when new data
            // arrives, it finds the old `observer.currentResult` which is related
            // to the old QueryKey. Which means that currentResult and selectData are
            // out of sync already.
            // To solve this, we move the cursor of the currentResult everytime
            // an observer reads an optimistic value.
            // When keeping the previous data, the result doesn't change until new
            // data arrives.
            this.currentResult = result;
            this.currentResultOptions = this.options;
            this.currentResultState = this.currentQuery.state;
        }
        return result;
    }
    getCurrentResult() {
        return this.currentResult;
    }
    trackResult(result) {
        const trackedResult = {};
        Object.keys(result).forEach((key)=>{
            Object.defineProperty(trackedResult, key, {
                configurable: false,
                enumerable: true,
                get: ()=>{
                    this.trackedProps.add(key);
                    return result[key];
                }
            });
        });
        return trackedResult;
    }
    getCurrentQuery() {
        return this.currentQuery;
    }
    remove() {
        this.client.getQueryCache().remove(this.currentQuery);
    }
    refetch({ refetchPage, ...options } = {}) {
        return this.fetch({
            ...options,
            meta: {
                refetchPage
            }
        });
    }
    fetchOptimistic(options) {
        const defaultedOptions = this.client.defaultQueryOptions(options);
        const query = this.client.getQueryCache().build(this.client, defaultedOptions);
        query.isFetchingOptimistic = true;
        return query.fetch().then(()=>this.createResult(query, defaultedOptions));
    }
    fetch(fetchOptions) {
        var _fetchOptions$cancelR;
        return this.executeFetch({
            ...fetchOptions,
            cancelRefetch: (_fetchOptions$cancelR = fetchOptions.cancelRefetch) != null ? _fetchOptions$cancelR : true
        }).then(()=>{
            this.updateResult();
            return this.currentResult;
        });
    }
    executeFetch(fetchOptions) {
        // Make sure we reference the latest query as the current one might have been removed
        this.updateQuery(); // Fetch
        let promise = this.currentQuery.fetch(this.options, fetchOptions);
        if (!(fetchOptions != null && fetchOptions.throwOnError)) {
            promise = promise.catch(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["noop"]);
        }
        return promise;
    }
    updateStaleTimeout() {
        this.clearStaleTimeout();
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] || this.currentResult.isStale || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidTimeout"])(this.options.staleTime)) {
            return;
        }
        const time = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["timeUntilStale"])(this.currentResult.dataUpdatedAt, this.options.staleTime); // The timeout is sometimes triggered 1 ms before the stale time expiration.
        // To mitigate this issue we always add 1 ms to the timeout.
        const timeout = time + 1;
        this.staleTimeoutId = setTimeout(()=>{
            if (!this.currentResult.isStale) {
                this.updateResult();
            }
        }, timeout);
    }
    computeRefetchInterval() {
        var _this$options$refetch;
        return typeof this.options.refetchInterval === 'function' ? this.options.refetchInterval(this.currentResult.data, this.currentQuery) : (_this$options$refetch = this.options.refetchInterval) != null ? _this$options$refetch : false;
    }
    updateRefetchInterval(nextInterval) {
        this.clearRefetchInterval();
        this.currentRefetchInterval = nextInterval;
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isServer"] || this.options.enabled === false || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isValidTimeout"])(this.currentRefetchInterval) || this.currentRefetchInterval === 0) {
            return;
        }
        this.refetchIntervalId = setInterval(()=>{
            if (this.options.refetchIntervalInBackground || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$focusManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["focusManager"].isFocused()) {
                this.executeFetch();
            }
        }, this.currentRefetchInterval);
    }
    updateTimers() {
        this.updateStaleTimeout();
        this.updateRefetchInterval(this.computeRefetchInterval());
    }
    clearStaleTimeout() {
        if (this.staleTimeoutId) {
            clearTimeout(this.staleTimeoutId);
            this.staleTimeoutId = undefined;
        }
    }
    clearRefetchInterval() {
        if (this.refetchIntervalId) {
            clearInterval(this.refetchIntervalId);
            this.refetchIntervalId = undefined;
        }
    }
    createResult(query, options) {
        const prevQuery = this.currentQuery;
        const prevOptions = this.options;
        const prevResult = this.currentResult;
        const prevResultState = this.currentResultState;
        const prevResultOptions = this.currentResultOptions;
        const queryChange = query !== prevQuery;
        const queryInitialState = queryChange ? query.state : this.currentQueryInitialState;
        const prevQueryResult = queryChange ? this.currentResult : this.previousQueryResult;
        const { state } = query;
        let { dataUpdatedAt, error, errorUpdatedAt, fetchStatus, status } = state;
        let isPreviousData = false;
        let isPlaceholderData = false;
        let data; // Optimistically set result in fetching state if needed
        if (options._optimisticResults) {
            const mounted = this.hasListeners();
            const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
            const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
            if (fetchOnMount || fetchOptionally) {
                fetchStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$retryer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["canFetch"])(query.options.networkMode) ? 'fetching' : 'paused';
                if (!dataUpdatedAt) {
                    status = 'loading';
                }
            }
            if (options._optimisticResults === 'isRestoring') {
                fetchStatus = 'idle';
            }
        } // Keep previous data if needed
        if (options.keepPreviousData && !state.dataUpdatedAt && prevQueryResult != null && prevQueryResult.isSuccess && status !== 'error') {
            data = prevQueryResult.data;
            dataUpdatedAt = prevQueryResult.dataUpdatedAt;
            status = prevQueryResult.status;
            isPreviousData = true;
        } else if (options.select && typeof state.data !== 'undefined') {
            // Memoize select result
            if (prevResult && state.data === (prevResultState == null ? void 0 : prevResultState.data) && options.select === this.selectFn) {
                data = this.selectResult;
            } else {
                try {
                    this.selectFn = options.select;
                    data = options.select(state.data);
                    data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceData"])(prevResult == null ? void 0 : prevResult.data, data, options);
                    this.selectResult = data;
                    this.selectError = null;
                } catch (selectError) {
                    if ("TURBOPACK compile-time truthy", 1) {
                        this.client.getLogger().error(selectError);
                    }
                    this.selectError = selectError;
                }
            }
        } else {
            data = state.data;
        } // Show placeholder data if needed
        if (typeof options.placeholderData !== 'undefined' && typeof data === 'undefined' && status === 'loading') {
            let placeholderData; // Memoize placeholder data
            if (prevResult != null && prevResult.isPlaceholderData && options.placeholderData === (prevResultOptions == null ? void 0 : prevResultOptions.placeholderData)) {
                placeholderData = prevResult.data;
            } else {
                placeholderData = typeof options.placeholderData === 'function' ? options.placeholderData() : options.placeholderData;
                if (options.select && typeof placeholderData !== 'undefined') {
                    try {
                        placeholderData = options.select(placeholderData);
                        this.selectError = null;
                    } catch (selectError) {
                        if ("TURBOPACK compile-time truthy", 1) {
                            this.client.getLogger().error(selectError);
                        }
                        this.selectError = selectError;
                    }
                }
            }
            if (typeof placeholderData !== 'undefined') {
                status = 'success';
                data = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["replaceData"])(prevResult == null ? void 0 : prevResult.data, placeholderData, options);
                isPlaceholderData = true;
            }
        }
        if (this.selectError) {
            error = this.selectError;
            data = this.selectResult;
            errorUpdatedAt = Date.now();
            status = 'error';
        }
        const isFetching = fetchStatus === 'fetching';
        const isLoading = status === 'loading';
        const isError = status === 'error';
        const result = {
            status,
            fetchStatus,
            isLoading,
            isSuccess: status === 'success',
            isError,
            isInitialLoading: isLoading && isFetching,
            data,
            dataUpdatedAt,
            error,
            errorUpdatedAt,
            failureCount: state.fetchFailureCount,
            failureReason: state.fetchFailureReason,
            errorUpdateCount: state.errorUpdateCount,
            isFetched: state.dataUpdateCount > 0 || state.errorUpdateCount > 0,
            isFetchedAfterMount: state.dataUpdateCount > queryInitialState.dataUpdateCount || state.errorUpdateCount > queryInitialState.errorUpdateCount,
            isFetching,
            isRefetching: isFetching && !isLoading,
            isLoadingError: isError && state.dataUpdatedAt === 0,
            isPaused: fetchStatus === 'paused',
            isPlaceholderData,
            isPreviousData,
            isRefetchError: isError && state.dataUpdatedAt !== 0,
            isStale: isStale(query, options),
            refetch: this.refetch,
            remove: this.remove
        };
        return result;
    }
    updateResult(notifyOptions) {
        const prevResult = this.currentResult;
        const nextResult = this.createResult(this.currentQuery, this.options);
        this.currentResultState = this.currentQuery.state;
        this.currentResultOptions = this.options; // Only notify and update result if something has changed
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqualObjects"])(nextResult, prevResult)) {
            return;
        }
        this.currentResult = nextResult; // Determine which callbacks to trigger
        const defaultNotifyOptions = {
            cache: true
        };
        const shouldNotifyListeners = ()=>{
            if (!prevResult) {
                return true;
            }
            const { notifyOnChangeProps } = this.options;
            const notifyOnChangePropsValue = typeof notifyOnChangeProps === 'function' ? notifyOnChangeProps() : notifyOnChangeProps;
            if (notifyOnChangePropsValue === 'all' || !notifyOnChangePropsValue && !this.trackedProps.size) {
                return true;
            }
            const includedProps = new Set(notifyOnChangePropsValue != null ? notifyOnChangePropsValue : this.trackedProps);
            if (this.options.useErrorBoundary) {
                includedProps.add('error');
            }
            return Object.keys(this.currentResult).some((key)=>{
                const typedKey = key;
                const changed = this.currentResult[typedKey] !== prevResult[typedKey];
                return changed && includedProps.has(typedKey);
            });
        };
        if ((notifyOptions == null ? void 0 : notifyOptions.listeners) !== false && shouldNotifyListeners()) {
            defaultNotifyOptions.listeners = true;
        }
        this.notify({
            ...defaultNotifyOptions,
            ...notifyOptions
        });
    }
    updateQuery() {
        const query = this.client.getQueryCache().build(this.client, this.options);
        if (query === this.currentQuery) {
            return;
        }
        const prevQuery = this.currentQuery;
        this.currentQuery = query;
        this.currentQueryInitialState = query.state;
        this.previousQueryResult = this.currentResult;
        if (this.hasListeners()) {
            prevQuery == null ? void 0 : prevQuery.removeObserver(this);
            query.addObserver(this);
        }
    }
    onQueryUpdate(action) {
        const notifyOptions = {};
        if (action.type === 'success') {
            notifyOptions.onSuccess = !action.manual;
        } else if (action.type === 'error' && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$retryer$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isCancelledError"])(action.error)) {
            notifyOptions.onError = true;
        }
        this.updateResult(notifyOptions);
        if (this.hasListeners()) {
            this.updateTimers();
        }
    }
    notify(notifyOptions) {
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$notifyManager$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notifyManager"].batch(()=>{
            // First trigger the configuration callbacks
            if (notifyOptions.onSuccess) {
                var _this$options$onSucce, _this$options, _this$options$onSettl, _this$options2;
                (_this$options$onSucce = (_this$options = this.options).onSuccess) == null ? void 0 : _this$options$onSucce.call(_this$options, this.currentResult.data);
                (_this$options$onSettl = (_this$options2 = this.options).onSettled) == null ? void 0 : _this$options$onSettl.call(_this$options2, this.currentResult.data, null);
            } else if (notifyOptions.onError) {
                var _this$options$onError, _this$options3, _this$options$onSettl2, _this$options4;
                (_this$options$onError = (_this$options3 = this.options).onError) == null ? void 0 : _this$options$onError.call(_this$options3, this.currentResult.error);
                (_this$options$onSettl2 = (_this$options4 = this.options).onSettled) == null ? void 0 : _this$options$onSettl2.call(_this$options4, undefined, this.currentResult.error);
            } // Then trigger the listeners
            if (notifyOptions.listeners) {
                this.listeners.forEach(({ listener })=>{
                    listener(this.currentResult);
                });
            } // Then the cache listeners
            if (notifyOptions.cache) {
                this.client.getQueryCache().notify({
                    query: this.currentQuery,
                    type: 'observerResultsUpdated'
                });
            }
        });
    }
}
function shouldLoadOnMount(query, options) {
    return options.enabled !== false && !query.state.dataUpdatedAt && !(query.state.status === 'error' && options.retryOnMount === false);
}
function shouldFetchOnMount(query, options) {
    return shouldLoadOnMount(query, options) || query.state.dataUpdatedAt > 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
    if (options.enabled !== false) {
        const value = typeof field === 'function' ? field(query) : field;
        return value === 'always' || value !== false && isStale(query, options);
    }
    return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
    return options.enabled !== false && (query !== prevQuery || prevOptions.enabled === false) && (!options.suspense || query.state.status !== 'error') && isStale(query, options);
}
function isStale(query, options) {
    return query.isStaleByTime(options.staleTime);
} // this function would decide if we will update the observer's 'current'
// properties after an optimistic reading via getOptimisticResult
function shouldAssignObserverCurrentProperties(observer, optimisticResult, options) {
    // it is important to keep this condition like this for three reasons:
    // 1. It will get removed in the v5
    // 2. it reads: don't update the properties if we want to keep the previous
    // data.
    // 3. The opposite condition (!options.keepPreviousData) would fallthrough
    // and will result in a bad decision
    if (options.keepPreviousData) {
        return false;
    } // this means we want to put some placeholder data when pending and queryKey
    // changed.
    if (options.placeholderData !== undefined) {
        // re-assign properties only if current data is placeholder data
        // which means that data did not arrive yet, so, if there is some cached data
        // we need to "prepare" to receive it
        return optimisticResult.isPlaceholderData;
    } // if the newly created result isn't what the observer is holding as current,
    // then we'll need to update the properties as well
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["shallowEqualObjects"])(observer.getCurrentResult(), optimisticResult)) {
        return true;
    } // basically, just keep previous properties if nothing changed
    return false;
}
;
 //# sourceMappingURL=queryObserver.mjs.map
}}),
"[project]/node_modules/@tanstack/react-query/build/lib/useQuery.mjs [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: require } = __turbopack_context__;
{
__turbopack_esm__({
    "useQuery": (()=>useQuery)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/utils.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useBaseQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/react-query/build/lib/useBaseQuery.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$queryObserver$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/@tanstack/query-core/build/lib/queryObserver.mjs [app-client] (ecmascript)");
'use client';
;
;
function useQuery(arg1, arg2, arg3) {
    const parsedOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$utils$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseQueryArgs"])(arg1, arg2, arg3);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$lib$2f$useBaseQuery$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBaseQuery"])(parsedOptions, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$query$2d$core$2f$build$2f$lib$2f$queryObserver$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["QueryObserver"]);
}
;
 //# sourceMappingURL=useQuery.mjs.map
}}),
}]);

//# sourceMappingURL=_effddb._.js.map