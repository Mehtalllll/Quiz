(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_products_page_tsx_02bf03._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_products_page_tsx_02bf03._.js",
  "chunks": [
    "static/chunks/_c8772a._.js"
  ],
  "source": "dynamic"
});
